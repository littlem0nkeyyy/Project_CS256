#include"Employee.hpp"
#include<iostream>
using namespace std;

void Employee::display() {
	cout << "This is employee information!" << endl;
}